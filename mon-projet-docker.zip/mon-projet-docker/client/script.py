import requests
import time

time.sleep(5)

try:
    r = requests.get("http://web:5000")
    print("Réponse du serveur web:", r.text)
except Exception as e:
    print("Erreur :", e)
